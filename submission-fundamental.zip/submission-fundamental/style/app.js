import "bootstrap/dist/css/bootstrap.min.css";
import "./style/style.css";
import "./src/scripts/components/footer-covid.js";
import "./src/scripts/components/data-covid.js";
import "./src/scripts/components/jumbotron-covid.js";
import "./src/scripts/components/appbar.js";
import main from "./src/scripts/main.js";

document.addEventListener("DOMContentLoaded", main);
