import "bootstrap/dist/css/bootstrap.min.css";

class datacovid extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `<section id="about">
    <div class="container">
      <div class="row text-center">
        <h2>Data Sebaran</h2>
      </div>
      <h3><b>Indonesia</b></h3>
      <p>update terakhir: 01-04-2022 </p>
      <div class="container">
        <div class="row">
          <div class="col bg-primary text-center">
            229
            <p>Positif</p>
          </div>
          <div class="col bg-warning text-center">
            
            <p>Sembuh</p>
          </div>
          <div class="col bg-danger text-center">
            
            <p>Meninggal Dunia</p>
          </div>
        </div>
      </div>
    </div>
  </section>`;
  }
}

customElements.define("data-covid", datacovid);
