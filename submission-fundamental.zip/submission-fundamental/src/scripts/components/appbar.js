import "./style/style.css";

class appbar extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `<h1>Covid-19</h1>`;
  }
}

customElements.define("app-bar", appbar);
