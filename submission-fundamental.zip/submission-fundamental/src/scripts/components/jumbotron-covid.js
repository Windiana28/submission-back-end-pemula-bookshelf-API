import "./src/image.illustration.svg";
import "bootstrap/dist/css/bootstrap.min.css";

class jumbotroncovid extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = ` <section class="jumbotron">
    <img src="./src/image/illustration.svg" alt="" width="300" />
    <h1 class="display-6">Pandemi COVID-19 di Indonesia</h1>
    <p class="lead">
      Pandemi COVID-19 di Indonesia merupakan bagian dari pandemi coronavirus disease 2019 (COVID-19) yang sedang berlangsung di seluruh dunia yang disebabkan oleh sindrom pernapasan akut parah coronavirus 2 (SARS-CoV-2). Dikonfirmasi
      telah menyebar ke Indonesia pada 2 Maret 2020, hingga 9 April 2020, pandemi telah menyebar ke 34 provinsi di Tanah Air.
    </p>
  </section>`;
  }
}

customElements.define("jumbotron-covid", jumbotroncovid);
