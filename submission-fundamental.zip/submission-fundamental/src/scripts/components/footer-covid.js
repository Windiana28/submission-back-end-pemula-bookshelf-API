class footercovid extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `<div class="container text-center mt-4">
    <p class="footer">&copy; 2022. Dibuat oleh windiana simangunsong.</p>
</div>`;
  }
}

customElements.define("footer-covid", footercovid);
