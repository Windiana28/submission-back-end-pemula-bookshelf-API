const main = () => {
  const getData = () => {
    fetch(baseUrl)
      .then((response) => response.json())
      .then((results) => {
        const datacovidElement = document.querySelector("data-covid");
        datacovidElement.coronaItem = results;
      })
      .catch((error) => showMessage());
  };

  const showMessage = (message = "Periksa koneksi internet...") => {
    alert(message);
  };

  getData();
};

export default main;
